var searchData=
[
  ['write_5frtc_5ftime',['write_rtc_time',['../class_nex_rtc.html#a9c55a15fa0a2b1511162facdc47f78b2',1,'NexRtc::write_rtc_time(char *time_type, uint32_t number)'],['../class_nex_rtc.html#ab11da59341b52b0f686cb85a058d0962',1,'NexRtc::write_rtc_time(uint32_t *time)']]]
];
